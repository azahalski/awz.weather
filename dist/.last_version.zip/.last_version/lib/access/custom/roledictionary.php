<?php
namespace Awz\Weather\Access\Custom;

use Awz\Weather\Access\Permission;

class RoleDictionary extends Permission\RoleDictionary
{
}