drop table if exists awz_weather_role;
drop table if exists awz_weather_role_relation;
drop table if exists awz_weather_permission;