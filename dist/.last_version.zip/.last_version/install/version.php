<?
$arModuleVersion = array(
	"VERSION" => "1.0.2",
	"VERSION_DATE" => "2025-06-22 12:00:00"
);
?>