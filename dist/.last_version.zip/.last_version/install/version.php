<?
$arModuleVersion = array(
	"VERSION" => "1.0.6",
	"VERSION_DATE" => "2025-06-26 16:03:00"
);
?>