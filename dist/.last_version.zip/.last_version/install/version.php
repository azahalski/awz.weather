<?
$arModuleVersion = array(
	"VERSION" => "1.0.7",
	"VERSION_DATE" => "2025-07-18 06:14:00"
);
?>