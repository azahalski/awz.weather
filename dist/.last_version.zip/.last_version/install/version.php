<?
$arModuleVersion = array(
	"VERSION" => "1.0.5",
	"VERSION_DATE" => "2025-06-22 13:06:00"
);
?>